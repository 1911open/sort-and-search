#include <stdio.h>
#include <stdlib.h>

typedef struct BEAR
{
    long id;
    long time;
    float start;
    float high;
    float low;
    float last;
    float trade;
    int order;
    char sign[2];
    int data[15];
}BEAR;

BEAR share[1680000];

long Save(FILE *fp)
{
    long i = 0;
    if((fp = fopen("Ex_5.txt","r")) == NULL)
    {
        printf("Error! Can't open this file!");
        exit(0);
    }

    while(!feof(fp))
    {
        fscanf(fp,"%ld%*c%ld%*c%f%*c%f%*c%f%*c%f%*c%f%*c%d%*c%c%c%*c%d%*c%d%*c%d%*c%d%*c%d%*c%d%*c%d%*c%d%*c%d%*c%d%*c%d%*c%d%*c%d%*c%d%*c%d%*c%d"
        "\n",&share[i].id, &share[i].time, &share[i].start, &share[i].high, &share[i].low, &share[i].last, &share[i].trade, &share[i].order
               ,&share[i].sign[0],&share[i].sign[1]
               , &share[i].data[0], &share[i].data[1], &share[i].data[2], &share[i].data[3], &share[i].data[4], &share[i].data[5], &share[i].data[6], &share[i].data[7], &share[i].data[8], &share[i].data[9], &share[i].data[10], &share[i].data[11], &share[i].data[12], &share[i].data[13], &share[i].data[14], &share[i].data[15]);
        i++;
        printf("\ninfo %d",i);
    }
    fclose(fp);
    return i;

}

void Main()
{
    printf("\n\t********************************"
           "\n\t\t1.Sorting with a n2 way."
           "\n\t\t2.Sorting with a nlogn way."
           "\n\t\t3.Sorting with a Sier way."
           "\n\t\t4.Seart in order."
           "\n\t\t5.Seart in index."
           "\n\t\t0.exit."
           "\n\t*********************************\n\n");
}



void Sort_n2(long i)
{
    long m = 0L, k = 0L;
    BEAR flag;
    for(m = 0; m < i; m++)
    {
        for(k = m; k < i; k++)
        {
            flag = share[m].trade > share[k].trade ? share[m] : share[k];
            share[k] = share[m].trade > share[k].trade ? share[k] : share[m];
        }
        share[m] = flag;
        printf("\n%ld times",m);
    }

}

void Sort_nlogn(long i)
{
    q_sort(1,i);
}

void q_sort(long low, long high)
{
    long prvotloc;
    if(low < high)
    {
        prvotloc = partions(low,high);
        q_sort(low,prvotloc - 1);
        q_sort(prvotloc + 1,high);
    }
}

int partions(long low, long high)
{
    BEAR prvotkey = share[low];
    share[0] = share[low];
    while(low < high)
    {
        while(low < high && share[high].trade >= prvotkey.trade)
            --high;
        share[low] = share[high];
        while(low < high && share[low].trade <= prvotkey.trade)
            ++low;
        share[high] = share[low];
    }
    share[low] = share[0];
    return low;
}

void Sort_shell(long i)
{
    int step;
    long k,j;
    BEAR temp;
    for(step = i/2; step >0; step/=2)
    {
        for(k = step; k < i; k++)
        {
            temp = share[k];
            for(j = k - step;(j >= 0 && temp.trade < share[j].trade); j -= step)
            {
                share[j+ step] = share[j];
            }
            share[j+step] = temp;
        }
    }

}

void Seart_a(long i)
{
    long data;
    long date;
    long j;
    printf("\nInput the data,date :");
    scanf("%ld %ld",&data,&date);
    for(j = 0; j < i && (share[j].id != data || share[j].time != date); j++);
    printf("\n%lf",share[j].trade);

}

int main()
{
    FILE *fp = NULL;
    int order;
    long i;

    i = Save(fp);
    while(1)
    {
        Main();
        printf("\nInput a order:");
        scanf(" %d",&order);

        switch(order)
        {
        case 1:
            Sort_n2(i);
            break;
        case 2:
            Sort_nlogn(i);
            break;
        case 3:
            Sort_shell(i);
            break;
        case 4:
            Seart_a(i);
            break;
        case 0:
            Seart_a(i);
            return 0;
        }
    }
}
